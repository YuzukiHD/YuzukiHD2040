<h1>先来点图片</h1>
<p> </p>
<p>正面图</p>
<p><img src="//image.lceda.cn/pullimage/IUxQrJLtTmL7oHy5o8vifwIGOqeWWSIzvD7O3ean.jpeg" alt="IUxQrJLtTmL7oHy5o8vifwIGOqeWWSIzvD7O3ean.jpeg" width="1200" height="827" /></p>
<p> </p>
<p>背面图</p>
<p><img src="//image.lceda.cn/pullimage/BlFtTZ5XBG4YQqJMoLIBKJIlpikgtsctYsMGeztY.jpeg" alt="BlFtTZ5XBG4YQqJMoLIBKJIlpikgtsctYsMGeztY.jpeg" width="1200" height="826" /></p>
<p> </p>
<h1>特点</h1>
<p>受到 <a href="https://github.com/Wren6991">Wren6991</a> 大佬的启发，通过驱动树莓派绝赞的可编程IO，使用RP2040驱动两块HDMI[1]的屏幕。经过测试，将RP2040超频至252MHz时，可以传输640*480p 60Hz的图像。</p>
<p><img src="//image.lceda.cn/pullimage/cofbppY0SQzGkrSSrUns68wbWM0SvyFUzLYUEYQ0.jpeg" alt="cofbppY0SQzGkrSSrUns68wbWM0SvyFUzLYUEYQ0.jpeg" /></p>
<h1>固件&amp;开发包</h1>
<ul><li><a href="https://github.com/YuzukiHD/YuzukiHD2040">https://github.com/YuzukiHD/YuzukiHD2040  </a></li>
</ul><p> </p>
<h4>注：</h4>
<p>[1]：HDMI兼容DVI，DVI信号可以通过物理转换接口将视频信号接到HDMI接口上。HDMI用在既能显示视频也能放出声音的显示器上（如液晶电视机），DVI只能用在单独的显示器上，无法输出声音。这里使用HDMI的物理接口但是传输的信号仍然是DVI</p>
<p>[2]：https://github.com/Wren6991/PicoDVI</p>
<p> </p>
<h1>来个视频</h1>
<p>显示字符，并每隔3秒对板子进行一次复位。</p>
<p> </p>            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。